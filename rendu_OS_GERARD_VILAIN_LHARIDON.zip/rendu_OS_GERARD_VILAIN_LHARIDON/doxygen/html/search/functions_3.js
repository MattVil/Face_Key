var searchData=
[
  ['first_5fconn_5froutine',['first_conn_routine',['../client_8c.html#abdbbb2ed12ec88b8baaef49290698cf9',1,'client.c']]]
];
