var searchData=
[
  ['take_5fpicture_2ecpp',['take_picture.cpp',['../take__picture_8cpp.html',1,'']]],
  ['test_2ehxx',['test.hxx',['../test_8hxx.html',1,'']]]
];
