var searchData=
[
  ['pidfork',['pidFork',['../client_8c.html#a6deddd055a77b54ab1be7b9b1e18491e',1,'pidFork():&#160;client.c'],['../reco_8cpp.html#a6deddd055a77b54ab1be7b9b1e18491e',1,'pidFork():&#160;reco.cpp']]],
  ['port_5fserv',['PORT_SERV',['../client_8c.html#a6b9af8a2bd43b8121ef7becd2af659a3',1,'client.c']]],
  ['privkey',['privkey',['../client_8c.html#a3be07c647a758988877c1da6fa7855b1',1,'privkey():&#160;client.c'],['../server_8c.html#a3be07c647a758988877c1da6fa7855b1',1,'privkey():&#160;server.c']]],
  ['pssw',['pssw',['../client_8c.html#a49d75f9e243701067636ce5978dd934b',1,'client.c']]],
  ['pubkey',['pubkey',['../client_8c.html#a3e7e5081a03a76a247ebb1cc3f1ec85c',1,'pubkey():&#160;client.c'],['../server_8c.html#a3e7e5081a03a76a247ebb1cc3f1ec85c',1,'pubkey():&#160;server.c']]]
];
