var searchData=
[
  ['semalloc',['semalloc',['../ipc_tools_8c.html#a1ced9d2738adfdc25ea838402d87e1f3',1,'semalloc(key_t key, int valInit):&#160;ipcTools.c'],['../ipc_tools_8h.html#a45c8a1cc742b770f79825e79aa0c8ce7',1,'semalloc(key_t key, int valInit):&#160;ipcTools.c']]],
  ['semfree',['semfree',['../ipc_tools_8c.html#a1a1666796045a3210edd37d16b0f9625',1,'semfree(int semid):&#160;ipcTools.c'],['../ipc_tools_8h.html#a1a1666796045a3210edd37d16b0f9625',1,'semfree(int semid):&#160;ipcTools.c']]],
  ['send_5fdata',['send_data',['../util2_8h.html#a0154a9439335d179a325861703fd4241',1,'util.c']]],
  ['send_5ffile',['send_file',['../util2_8h.html#af9c2aa3594e0fd3bea776fb62a880097',1,'util.c']]],
  ['send_5ffile2',['send_file2',['../util2_8h.html#a34055649bf39bc9498d9c150f0f3fa09',1,'util.c']]],
  ['shmalloc',['shmalloc',['../ipc_tools_8c.html#a2388152033ebd5306bb178e3078b5118',1,'shmalloc(key_t key, int size):&#160;ipcTools.c'],['../ipc_tools_8h.html#aaae3779ba3c90a6bd1db639fd20ef251',1,'shmalloc(key_t key, int size):&#160;ipcTools.c']]],
  ['shmfree',['shmfree',['../ipc_tools_8c.html#af6b34b8a7db92f7b60d335e3f06b8e34',1,'shmfree(key_t key):&#160;ipcTools.c'],['../ipc_tools_8h.html#af6b34b8a7db92f7b60d335e3f06b8e34',1,'shmfree(key_t key):&#160;ipcTools.c']]],
  ['split_5fmessage',['split_message',['../util2_8h.html#a4f3772de5f32394d69f4b07d96503764',1,'util.c']]],
  ['str_5fsplit',['str_split',['../util2_8h.html#a5fe3005ed280456e83c9d1bafee2a687',1,'util.c']]]
];
