var searchData=
[
  ['tube',['tube',['../client_8c.html#af3d9e4d2bdcc52e79e5635833b3b6712',1,'tube():&#160;client.c'],['../reco_8cpp.html#af3d9e4d2bdcc52e79e5635833b3b6712',1,'tube():&#160;reco.cpp']]],
  ['tubebuffer',['tubeBuffer',['../client_8c.html#ac0c9b1f044ac04a5dadf063aa6e09915',1,'tubeBuffer():&#160;client.c'],['../reco_8cpp.html#ac0c9b1f044ac04a5dadf063aa6e09915',1,'tubeBuffer():&#160;reco.cpp']]]
];
