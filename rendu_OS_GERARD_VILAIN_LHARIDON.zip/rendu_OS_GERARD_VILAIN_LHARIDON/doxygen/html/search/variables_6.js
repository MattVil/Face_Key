var searchData=
[
  ['mail',['mail',['../structnode.html#af236e8ba7815eda2ff7daf67c80043bb',1,'node']]]
];
