var searchData=
[
  ['weight_5fupdate_5froutine',['weight_update_routine',['../client_8c.html#a195e7e824b505e0e09ea0cd5a3496694',1,'client.c']]],
  ['write_5ffile',['write_file',['../util2_8h.html#add086f6437ca0722ae0810a371f7586a',1,'util2.h']]]
];
