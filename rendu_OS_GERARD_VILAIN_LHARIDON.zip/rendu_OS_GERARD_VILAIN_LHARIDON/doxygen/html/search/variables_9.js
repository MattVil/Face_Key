var searchData=
[
  ['semid',['semid',['../client_8c.html#a7c35ac5305085cf7360645b8d52988b5',1,'semid():&#160;client.c'],['../reco_8cpp.html#a7c35ac5305085cf7360645b8d52988b5',1,'semid():&#160;reco.cpp']]],
  ['semkey',['semkey',['../client_8c.html#a9600f47d09dee34e6da9bd490fa6bafc',1,'semkey():&#160;client.c'],['../reco_8cpp.html#a9600f47d09dee34e6da9bd490fa6bafc',1,'semkey():&#160;reco.cpp']]],
  ['shmkey',['shmkey',['../client_8c.html#a39f28a67ceaf4beb0430971633c5e2d3',1,'shmkey():&#160;client.c'],['../reco_8cpp.html#a39f28a67ceaf4beb0430971633c5e2d3',1,'shmkey():&#160;reco.cpp']]],
  ['st',['st',['../take__picture_8cpp.html#a909b9c34d788f026a675e03094d3085b',1,'take_picture.cpp']]]
];
