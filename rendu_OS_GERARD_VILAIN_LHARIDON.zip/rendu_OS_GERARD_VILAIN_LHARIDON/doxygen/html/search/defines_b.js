var searchData=
[
  ['ok',['OK',['../util_8h.html#aba51915c87d64af47fb1cc59348961c9',1,'OK():&#160;util.h'],['../util2_8h.html#aba51915c87d64af47fb1cc59348961c9',1,'OK():&#160;util2.h']]],
  ['online',['ONLINE',['../util_8h.html#a5d8d172be98804c39bb311ead048123a',1,'ONLINE():&#160;util.h'],['../util2_8h.html#a5d8d172be98804c39bb311ead048123a',1,'ONLINE():&#160;util2.h']]]
];
