var searchData=
[
  ['db_5fdisplay_5fresult',['db_display_result',['../dbutil_8c.html#ac7bad5938cf758a4be376024d06fd4ed',1,'db_display_result(PGresult *result):&#160;dbutil.c'],['../dbutil_8h.html#a2c3353bdcfd43c09256570028add60d5',1,'db_display_result(PGresult *result):&#160;dbutil.c']]],
  ['db_5fexit_5fnicely',['db_exit_nicely',['../dbutil_8c.html#a191689b983befcd2fb56dd708b4788b7',1,'db_exit_nicely(PGconn *conn):&#160;dbutil.c'],['../dbutil_8h.html#a191689b983befcd2fb56dd708b4788b7',1,'db_exit_nicely(PGconn *conn):&#160;dbutil.c']]],
  ['dbutil_2ec',['dbutil.c',['../dbutil_8c.html',1,'']]],
  ['dbutil_2eh',['dbutil.h',['../dbutil_8h.html',1,'']]],
  ['deprecated_20list',['Deprecated List',['../deprecated.html',1,'']]]
];
