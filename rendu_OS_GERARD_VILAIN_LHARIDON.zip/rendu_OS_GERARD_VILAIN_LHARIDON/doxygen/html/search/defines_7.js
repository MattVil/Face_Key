var searchData=
[
  ['id_5finfo',['ID_INFO',['../util_8h.html#a4e311ab51c3b2c5b27d170ae0169759b',1,'ID_INFO():&#160;util.h'],['../util2_8h.html#a4e311ab51c3b2c5b27d170ae0169759b',1,'ID_INFO():&#160;util2.h']]],
  ['ids_5frequ',['IDS_REQU',['../util_8h.html#acf24ad9f8a85c69adaf5369f44f455d3',1,'IDS_REQU():&#160;util.h'],['../util2_8h.html#acf24ad9f8a85c69adaf5369f44f455d3',1,'IDS_REQU():&#160;util2.h']]],
  ['ids_5fsd',['IDS_SD',['../util_8h.html#acc4a86f5420ccadc8505385c3913e07f',1,'IDS_SD():&#160;util.h'],['../util2_8h.html#acc4a86f5420ccadc8505385c3913e07f',1,'IDS_SD():&#160;util2.h']]],
  ['image_5fsize',['IMAGE_SIZE',['../take__picture_8cpp.html#a03231544d56f41bf8432d385c56ac927',1,'take_picture.cpp']]]
];
