var searchData=
[
  ['id_5fclient',['ID_CLIENT',['../client_8c.html#ae93dfddcf4362ff6e074b9b9b39af65b',1,'client.c']]],
  ['ip_5fserv',['IP_SERV',['../client_8c.html#a5f429265cf906682c7cb686f7b392280',1,'client.c']]]
];
