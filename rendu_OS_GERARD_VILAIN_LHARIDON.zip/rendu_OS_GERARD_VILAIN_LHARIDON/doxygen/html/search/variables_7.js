var searchData=
[
  ['nb_5fimages',['nb_images',['../take__picture_8cpp.html#ae2e41bb3a59a2d21905a767a95c010f1',1,'take_picture.cpp']]],
  ['next',['next',['../structnode.html#a0dc1b6470487aa86d9936e3cab8b95be',1,'node']]]
];
