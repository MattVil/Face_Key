var searchData=
[
  ['p',['P',['../ipc_tools_8c.html#a07d9975feec68c95cb5aba62b9d24ed8',1,'P(int semid):&#160;ipcTools.c'],['../ipc_tools_8h.html#a07d9975feec68c95cb5aba62b9d24ed8',1,'P(int semid):&#160;ipcTools.c']]],
  ['photo_5ftransfer_5froutine',['photo_transfer_routine',['../client_8c.html#a124725ea9dac50f4418f6db0cb175baf',1,'client.c']]],
  ['print_5fsplt_5fstr',['print_splt_str',['../util2_8h.html#afd92f62abb45abcd7a0e29cffb5b30ad',1,'util.c']]]
];
