var searchData=
[
  ['data_5fsep',['DATA_SEP',['../util_8h.html#a763e8511795cf98bbd5d6ff6161295a8',1,'DATA_SEP():&#160;util.h'],['../util2_8h.html#a763e8511795cf98bbd5d6ff6161295a8',1,'DATA_SEP():&#160;util2.h']]],
  ['debug',['DEBUG',['../util_8h.html#ad72dbcf6d0153db1b8d8a58001feed83',1,'DEBUG():&#160;util.h'],['../util2_8h.html#ad72dbcf6d0153db1b8d8a58001feed83',1,'DEBUG():&#160;util2.h']]]
];
