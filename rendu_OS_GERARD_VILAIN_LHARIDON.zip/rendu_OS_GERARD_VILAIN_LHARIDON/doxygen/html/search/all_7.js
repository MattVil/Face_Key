var searchData=
[
  ['neuralnetwork',['neuralNetwork',['../client_8c.html#a90937619433bf894fd8ebc6a36fdc015',1,'client.c']]],
  ['node',['node',['../structnode.html',1,'']]]
];
