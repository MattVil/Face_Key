var searchData=
[
  ['v',['V',['../ipc_tools_8c.html#a8a7b1645beb620891b3a8256143791e4',1,'V(int semid):&#160;ipcTools.c'],['../ipc_tools_8h.html#a8a7b1645beb620891b3a8256143791e4',1,'V(int semid):&#160;ipcTools.c']]],
  ['verif_5fconn',['verif_conn',['../server_8c.html#a334a0afee97de9c573574a8172793799',1,'server.c']]]
];
