var searchData=
[
  ['client_2ec',['client.c',['../client_8c.html',1,'']]]
];
