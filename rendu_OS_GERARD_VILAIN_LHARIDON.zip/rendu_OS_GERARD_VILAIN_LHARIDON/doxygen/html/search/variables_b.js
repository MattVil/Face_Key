var searchData=
[
  ['version',['version',['../client_8c.html#a11cb859eea495d07a75554d4c1079eca',1,'client.c']]]
];
