var searchData=
[
  ['getcode',['getCode',['../util2_8h.html#a44c1ee7356dd1dcacbfeb01d8feb0fdc',1,'util.c']]],
  ['getdata',['getData',['../util2_8h.html#adeb2af96dc9ecc2366fd7d6518a4a956',1,'util.c']]]
];
