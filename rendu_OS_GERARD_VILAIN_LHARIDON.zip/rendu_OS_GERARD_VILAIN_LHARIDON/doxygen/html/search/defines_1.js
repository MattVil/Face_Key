var searchData=
[
  ['buf_5ffile',['BUF_FILE',['../util_8h.html#a2974d51457222045bacaa15640605391',1,'BUF_FILE():&#160;util.h'],['../util2_8h.html#a2974d51457222045bacaa15640605391',1,'BUF_FILE():&#160;util2.h']]],
  ['buf_5fsize',['BUF_SIZE',['../util_8h.html#a6821bafc3c88dfb2e433a095df9940c6',1,'BUF_SIZE():&#160;util.h'],['../util2_8h.html#a6821bafc3c88dfb2e433a095df9940c6',1,'BUF_SIZE():&#160;util2.h']]],
  ['buflen',['BUFLEN',['../client__simple__chrome_8c.html#ad974fe981249f5e84fbf1683b012c9f8',1,'client_simple_chrome.c']]]
];
