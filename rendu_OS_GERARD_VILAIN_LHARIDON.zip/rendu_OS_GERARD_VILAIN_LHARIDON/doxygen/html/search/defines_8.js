var searchData=
[
  ['last_5fphoto',['LAST_PHOTO',['../util_8h.html#ad5ad9895ef638c5abda24f3b17a49a30',1,'LAST_PHOTO():&#160;util.h'],['../util2_8h.html#ad5ad9895ef638c5abda24f3b17a49a30',1,'LAST_PHOTO():&#160;util2.h']]],
  ['log_5fcrea',['LOG_CREA',['../util_8h.html#a2c0063d503c3ec0f52a70a59c8765d1e',1,'LOG_CREA():&#160;util.h'],['../util2_8h.html#a2c0063d503c3ec0f52a70a59c8765d1e',1,'LOG_CREA():&#160;util2.h']]]
];
