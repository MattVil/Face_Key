var searchData=
[
  ['read_5ffile',['read_file',['../util2_8h.html#aba5c2ac08a8cdc8c13762ad4bf247e23',1,'util.c']]],
  ['receive_5ffile',['receive_file',['../util2_8h.html#a7c54beb694eb57c3827a5842be49c892',1,'util.c']]],
  ['receive_5ffile2',['receive_file2',['../util2_8h.html#a695421f9fe069b62563ff4af9f26de21',1,'util.c']]],
  ['recognition',['recognition',['../client_8c.html#a128f2bef3aaf93d50acf00ef8b1e0b97',1,'client.c']]],
  ['recv_5fdata',['recv_data',['../util2_8h.html#a68cbefaa3ae16a5fc97c9566d35320b4',1,'util.c']]],
  ['removechar',['removechar',['../util2_8h.html#a5b3e4ffa9a2462c18c62d44ba01f4042',1,'util.c']]]
];
